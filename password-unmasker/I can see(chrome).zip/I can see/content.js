(function togglePasswords() {
  const inputs = document.querySelectorAll('input[type="password"], input[type="text"]');
  inputs.forEach(input => {
    if (input.dataset.originalType === "password") {
      input.type = "password";
      delete input.dataset.originalType;
    } else if (input.type === "password") {
      input.dataset.originalType = "password";
      input.type = "text";
    }
  });
})();
